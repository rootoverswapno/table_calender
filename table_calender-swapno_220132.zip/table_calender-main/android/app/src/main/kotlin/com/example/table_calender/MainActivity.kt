package com.example.table_calender

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
