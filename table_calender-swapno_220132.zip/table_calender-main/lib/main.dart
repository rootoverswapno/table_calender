import 'package:flutter/material.dart';
import 'package:table_calender/T_calendar.dart';

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyApp(),
    )
  );
}

